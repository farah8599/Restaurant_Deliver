#include "ArrivalEvent.h"
#include "..\Rest\Restaurant.h"


ArrivalEvent::ArrivalEvent(int eTime, int oID, ORD_TYPE oType, REGION reg,int tDistance,double tMoney):Event(eTime, oID)
{
	OrdType = oType;
	OrdRegion = reg;
	OrdDistance=tDistance;
	OrdMoney=tMoney;
}

void ArrivalEvent::Execute(Restaurant* pRest)
{

	//This function should create and order and and fills its data 
	// Then adds it to normal, frozen, or VIP order lists 
	Order* pOrd = new Order(OrderID,OrdType,OrdRegion,EventTime,OrdMoney,OrdDistance);
	pRest->AddtoOrdersList(pOrd);
	
}
