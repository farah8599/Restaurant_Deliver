#include "CancellationEvent.h"
#include "..\Rest\Restaurant.h"

CancellationEvent::CancellationEvent(int eTime, int oID):Event(eTime, oID)
{
}

void CancellationEvent::Execute(Restaurant* pRest)
{
	//This function should cancel a normal order and deallocate it
	Region* R = pRest->getRegions();
	for (int i = 0; i<REG_CNT ; i++)
	{
		Order*const* Orders = R[i].NormalOrders.toArray();
		int C = R[i].NormalOrders.getlength();
		for(int j=0 ; j<C ;j++)
		{
			if(Orders[j]->GetID() == OrderID)
			{
				R[i].NormalOrders.remove(j);
				break;
			}
		}


	}

}
