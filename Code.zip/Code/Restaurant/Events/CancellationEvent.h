#ifndef __CANCELLATION_EVENT_H_
#define __CANCELLATION_EVENT_H_

#include "Event.h"


//class for the cancellation event
class CancellationEvent: public Event
{	
public:
	CancellationEvent(int eTime, int oID);
	
	virtual void Execute(Restaurant *pRest);	//override execute function

};

#endif