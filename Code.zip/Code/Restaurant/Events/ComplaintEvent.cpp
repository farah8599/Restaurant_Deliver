#include "ComplaintEvent.h"
#include "../Rest/Restaurant.h"

ComplaintEvent::ComplaintEvent(int eTime, int oID)
	:Event(eTime, oID)
{

}

void ComplaintEvent::Execute(Restaurant *pRest)
{
	pRest->Complain(OrderID);
}
