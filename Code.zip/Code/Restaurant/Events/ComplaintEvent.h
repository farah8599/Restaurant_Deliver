#pragma once
#include "Event.h"

//class for the Complaint event
class ComplaintEvent : public Event
{

public:
	ComplaintEvent(int eTime, int oID);
	virtual void Execute(Restaurant *pRest);	//override execute function

};
