#include "PromotionEvent.h"
#include "..\Rest\Restaurant.h"


PromotionEvent::PromotionEvent(int eTime, int oID, double ExMon):Event(eTime, oID)
{
	ExMoney=ExMon;
}

void PromotionEvent::Execute(Restaurant* pRest)
{
	//This function should promote a normal event to VIP and increment its total money by the extra amount and updates its priority
	Region* R = pRest->getRegions();
	for (int i = 0; i < REG_CNT; i++)
	{
		Order*const* Orders = R[i].NormalOrders.toArray();
		int C= R[i].NormalOrders.getlength();
		//int c = orders.size;
		for (int j = 0; j < C; j++)
		{
			if (Orders[j]->GetID() == OrderID)
			{
				Order* Ord = R[i].NormalOrders.getEntry(j);
				Ord->SetMoney(ExMoney+Ord->getMoney());
				Ord->SetType(TYPE_VIP);
				R[i].NormalOrders.remove(j);
				Ord->UpdatePriority();
				pRest->AddtoOrdersList(Ord);
				break;
			}
			
		}
		
	}

}
