#ifndef __PROMOTION_EVENT_H_
#define __PROMOTION_EVENT_H_

#include "Event.h"


//class for the promotion event
class PromotionEvent: public Event
{
	//info about the order related to promotion event	                
	double ExMoney;	//Extra money paid for promotion
public:
	PromotionEvent(int eTime, int oID, double ExMon);
	
	virtual void Execute(Restaurant *pRest);	//override execute function

};

#endif