
#ifndef _LINKED_BAG
#define _LINKED_BAG
#include "Node.h"
template< class T>
class Bag 

{
private:
 Node<T>* head; // Pointer to first node
 int count; // Current count of bag items
 Node<T>* getPointerTo( const T& target) const;
public:
 Bag();
 Bag(const Bag<T>& aBag); // Copy constructor
 virtual ~Bag(); // Destructor should be virtual
 int getCurrentSize() const;
 bool isEmpty() const;
 bool add( const T& newEntry);
 bool remove( const T& anEntry);
 void clear();
 bool contains( const T& anEntry) const;
 int getFrequencyOf( const T& anEntry) const;

}; // end LinkedBag 

//////////////////////////////////////////////////////////////////////////////
template< class T>
Node<T>* Bag<T>::getPointerTo( const T& target) const
{ 
  Node <T>*scanptr= head;
  while (scanptr)
  {
    if(scanptr->getItem()==target)
    {
      return scanptr; 
    }
    scanptr= scanptr->getNext();
  }
  return NULL;
  }
////////////////////////////////////////
template< class T>
Bag<T>::Bag()
{
 head= NULL;
 count=0;
}
/////////////////////////////////////////////
template< class T>
Bag<T>::(const Bag<T>& aBag)
{
  count = aBag->count;
 Node<T>* origChainPtr = aBag->head
if (origChainPtr == NULL)
 head = NULL; // Original bag is empty; so is copy
else
 {
 // Copy first node
 head = new Node<T>();
 head->setItem(origChainPtr ->getItem());
// Copy remaining nodes
 Node<T>* newChainPtr = head; // Last-node pointer
while (origPtr != NULL)
{
 origChainPtr = origChainPtr ->getNext(); // Advance pointer
 // Get next item from original chain
 T nextItem = origChainPtr->getItem();
 // Create a new node containing the next item
 Node<T>* newNodePtr = new Node<T>(nextItem); 
 // Link new node to end of new chain
 newChainPtr->setNext(newNodePtr);
 // Advance pointer to new last node
 newChainPtr = newChainPtr->getNext();
 } 
 newChainPtr->setNext( NULL); // Flag end of new chain
 } 
} 

}
///////////////////////////////////////////
template< class T>
Bag<T>::~Bag()
{
  clear();
}
///////////////////////////////////////////

template< class T>
int Bag<T>::getCurrentSize() const
{
 Node <T>*scanptr= head;
 int count=0;
 while (scanptr!= NULL)
 {
   count++;
   scanptr= scanptr->getNext();
 }
return count;
}
////////////////////////////////////

template< class T>
bool Bag<T>::isEmpty() const
{
  if(head==NULL)
   return true;
return false;
}
/////////////////////////////////////
template< class T>
bool Bag<T>::add( const T& newEntry)
{
  Node<T>* ptr= new Node;
  if (ptr==NULL) // this means no space in memory
    return false;
  ptr->setItem (newEntry);
  ptr->setNext (head);
  head= ptr;
return true;
}

///////////////////////////////////////////////////
template< class T>
bool Bag<T>::remove( const T& anEntry)
{
  if (isEmpty())
   return false;
  Node<T>* loc= getPointerTo(anEntry);
  if(loc==NULL)
  return false;
  loc->setItem(head->getItem());
  loc=head;
  head=head->getNext();
  delete loc;
  count--;
  return true;
}
///////////////////////////////////////
template< class T>
void Bag<T>::clear()
{
  Node<T>* clrptr=head;
  while (clrptr)
  {
    head= clrptr->getNext();
    delete clrptr;
    clrptr=head;
  }
  count=0;
}
////////////////////////////////////////
template< class T>
bool Bag<T>::contains( const T& anEntry) const
{
  Node<T>* found= getPointerTo(anEntry);
  if(found==NULL)
   return false;
  return true;  
}
///////////////////////////////////////////
template< class T>
int Bag<T>::getFrequencyOf( const T& anEntry) const
{
  Node<T>* scanptr=head;
  int frequency=0;
  int counter=0;
  while ((scanptr!= NULL) && (counter<count))
  {
    if(scanptr->getItem()== anEntry)
    {
      frequency++;   
    }
    counter++;
    scanptr=scanptr->getNext();
  }
  return frequency;
}
#endif