
#ifndef _ARRAY_BAG
#define _ARRAY_BAG
#define MAX 100

template<class T>
class BagArr
{
private:

T items[MAX]; // Array of bag items
int count; // Current count of bag items
int getIndexOf(const T& target) const;

public:
BagArr();
int getCurrentSize() const;
bool isEmpty() const;
bool add(const T& newEntry);
bool remove(const T& anEntry);
void clear();
bool contains(const T& anEntry) const;
int getFrequencyOf(const T& anEntry) const;
T* ToArray() const;

}; // end ArrayBag 

///////////////////////////////////////////////////////////////////////////

template<class T>
int BagArr<T>::getIndexOf(const T& target) const
{
 bool found= false;
 int result=-1;
 int SearchIndex=0;

 while (!found &&(SearchIndex<count))
 {
   if (items[SearchIndex]== target)
   {
     found= true;
     result=SearchIndex;
   }
   else
    SearchIndex++; 
 }
 return result;
}

////////////////////////////////////////////
template<class T>
BagArr<T>::BagArr() 
{
 count = 0;
 
} 

////////////////////////////////////////
template<class T>
int BagArr<T>::getCurrentSize() const
{
   return count;
}

////////////////////////////////////////
template<class T>
bool BagArr<T>::isEmpty() const
{
  if (count==0)
     return true;
  return false;
}
/////////////////////////////////////////////
template<class T>
bool BagArr<T>::add(const T& newEntry)
{
  if (count==MAX)
    return false;
  items[count++]= newEntry;
  return true;

}
///////////////////////////////////////
template<class T>
bool BagArr<T>::remove(const T& anEntry)
{
  int index=getIndexOf(anEntry);
  if(index==-1)
    return false;
  items[index]=item[count-1];
  count--;
  return true;
}
//////////////////////////////////////////
template<class T>
void BagArr<T>::clear()
{
  count=0;
}
///////////////////////////////////////////
template<class T>
bool BagArr<T>::contains(const T& anEntry) const
{
  int index=getIndexOf(anEntry);
  if(index==-1)
    return false;
  return true; 

}
/////////////////////////////////////////////////////////
template<class T>
int BagArr<T>::getFrequencyOf(const T& anEntry) const
{
  int frequency=0;
  int CurrIndex=0; // Current array index
  while (CurrIndex <count)
  {
    if (items[CurrIndex]== anEntry)
    { 
       frequency++;
    }
    CurrIndex++;
  }
  return frequency;
}

template <class T>
T* BagArr<T>::ToArray()const
{
	return items;
}
#endif