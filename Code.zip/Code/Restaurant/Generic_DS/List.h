#pragma once
#include <iostream>
#include "Node.h"
using namespace std;

template <class T>
class List
{
	Node<T>* head;
	Node<T>* tail;
	int itemcount;
	Node<T>* getNodeAt(int position) const;
public:
	List();
	bool isEmpty() const;
	int getlength() const;
	bool insert(int position, const T& newEntry);
	bool insert(const T& newEntry);
	bool remove(int position);
	bool remove(Node<T>* toDel);
	bool remove();
	T getEntry(int position);
	const T* toArray() const;
	void clear();
	~List();
};

template <class T>
List<T>::List()
	:head(NULL), itemcount(0), tail(NULL)
{}


template <class T>
bool List<T>:: isEmpty() const 
{
	return (itemcount == 0);
}

template <class T>
int List<T>::getlength() const
{
	return itemcount;
}

template <class T>
Node<T>* List<T>::getNodeAt(int position)const
{
	if (position < 0 || position >= itemcount)
		return NULL;
	Node<T>* currPtr = head;
	for (int i = 0; i < position; i++)
		currPtr = currPtr->getNext();
	return currPtr;
}

template <class T>
bool List<T>::insert(int position, const T& newEntry)
{
	if (position < 0 || position > itemcount)
		return false;
	if (position == 0)
	{
		Node<T>* ptr = new Node<T>;
		ptr->setItem(newEntry);
		ptr->setNext(head);
		head = ptr;
		return true;
	}
	Node<T>* nptr = getNodeAt(position - 1);
	Node<T>* ptr = new Node<T>;
	ptr->setItem(newEntry);
	ptr->setNext(nptr->getNext());
	nptr->setNext(ptr);
	itemcount++;
	return true;
}

template <class T>
bool List<T>::insert(const T& newEntry)
{
	Node<T>* ptr = new Node<T>;
	if (ptr == NULL) return false;
	ptr->setItem(newEntry);
	if (head==NULL)
	{
		head=ptr;
		tail=ptr;
		itemcount++;
		return true;
	}
	tail->setNext(ptr);
	tail = ptr;
	itemcount++;
	return true;

}

template <class T>
bool List<T>::remove(int position)
{
	if (position < 0 || position >= itemcount)
		return false;
	if (position == 0)
	{
		Node<T>*temp = head;
		head = temp->getNext();
		delete temp;
		itemcount--;
		return true;
	}
	Node<T>* ptr = getNodeAt(position - 1);
	Node<T>* temp = ptr->getNext();
	ptr->setNext(temp->getNext());
	delete temp;
	itemcount--;
	return true;
}

template <class T>
bool List<T>::remove(Node<T>* toDel)
{
	if (toDel == NULL) return false;
	if (isEmpty() == true) return false;
	Node<T>*ptr = head;
	if (toDel->getItem() == head->getItem())
	{
		Node<T> *temp = head;
		head = head->getNext();
		delete temp;
		itemcount--;
		return true;
	}
	while (ptr && ptr->getNext())
	{
		if (toDel->getItem() == ptr->getNext()->getItem())
		{
			Node<T>*temp = ptr->getNext();
			ptr->setNext(ptr->getNext()->getNext());
			delete temp;
			itemcount--;
			return true;
		}
		ptr = ptr->getNext();
	}
	return false;

}

template <class T>
bool List<T>::remove()
{
	if (isEmpty() == true) return false;
	Node<T>*temp = head;
	head = temp->getNext();
if (temp==tail)	 // Special case: one node in queue
		tail=head=nullptr ;
	delete temp;
	itemcount--;
	return true;
}


template < class T> 
T List<T>::getEntry(int position) 
{ 
	Node<T>* nodePtr = getNodeAt(position);
	if(nodePtr)
	return nodePtr->getItem();
} 

template <class T>
void List<T>:: clear()
{
	while (!isEmpty())
		remove(0);
}

template <class T>
List<T>::~List()
{
	clear();
}

template < class T>
 const T* List<T>::toArray() const
{
	T* ListContents = new T [itemcount]; 
	Node<T>* curPtr = head;
	int counter = 0;
	while ((curPtr != nullptr) && (counter < itemcount))
	{
		ListContents[counter] = curPtr->getItem();
		curPtr = curPtr->getNext();
		counter++;
	} // end while
	return ListContents;
} // end toArray