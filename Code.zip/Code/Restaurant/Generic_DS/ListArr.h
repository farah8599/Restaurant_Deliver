#pragma once
#include <iostream>
using namespace std;

#define MAX 100
template <class T>
class ListArr
{
	T arr[MAX];
	int count;
public:
	ListArr();
	bool isEmpty() const;
	int getlength() const;
	bool insert(int position, const T& newEntry);
	bool remove(int position);
	void clear();
};

template <class T>
ListArr<T>::ListArr<T>()
{
	count = 0;
}

template <class T>
bool ListArr<T>::isEmpty() const
{
	return (count == 0);
}

template <class T>
int ListArr<T>::getlength() const
{
	return count;
}

template <class T>
bool ListArr<T>::insert(int position, const T& newEntry)
{
	if (position<0 || position>count || count == MAX)
		return false;
	for (int i = count; i > position; i--)
		arr[i] = arr[i - 1];
	arr[position] = newEntry;
	count++;
	return true;
}

template <class T>
bool ListArr<T>::remove(int position)
{
	if (position<0 || position>count = )
		return false;
	for (int i = position; i < count;i++)
		arr[i] = arr[i + 1];
	count--;
	return true;
}

template <class T>
void ListArr<T>::clear()
{
	count = 0;
}