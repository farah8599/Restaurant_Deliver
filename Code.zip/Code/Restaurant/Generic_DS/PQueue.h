#ifndef _PQueue
#define _PQueue
#include "Queue.h"
#include "Node.h"
template <class T>
class PQueue:public Queue<T>
{
private:

public:
	PQueue();
	~PQueue();
 virtual bool enqueue(const T& newEntry,double pri);
};
 
/////////////////////////////////////////////////////////////////////////////////////////
template <class T>
PQueue<T>::PQueue()
{}
/////////////////////////////////////////////////////////////////////////////////////////
template <class T>
PQueue<T>::~PQueue()
{}
/////////////////////////////////////////////////////////////////////////////////////////


template <class T>
bool PQueue<T>::enqueue(const T& newEntry,double Pri)
{
	Node<T>* newNodePtr = new Node<T>(newEntry);
	newNodePtr->setPriority(Pri);
	// Insert the new node
	if (isEmpty())
	{
		frontPtr = newNodePtr; // The queue is empty
		backPtr=newNodePtr;
		itemcount++;
		return true;
	}
	if (Pri>=frontPtr->getPriority())
	{
		newNodePtr->setNext(frontPtr);
		frontPtr=newNodePtr;
		itemcount++;
		return true;
	}
	Node<T>* ScanPtr=frontPtr;
	while (ScanPtr->getNext())
	{
		if (Pri>=ScanPtr->getNext()->getPriority())
		{
			newNodePtr->setNext(ScanPtr->getNext());
			ScanPtr->setNext(newNodePtr);
			itemcount++;
			return true;
		}
		ScanPtr=ScanPtr->getNext();
	}
	ScanPtr->setNext(newNodePtr);
	backPtr=newNodePtr;
	itemcount++;
	return true;
}

#endif