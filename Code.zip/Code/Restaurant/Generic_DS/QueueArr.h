#ifndef __QUEUEARR_H_
#define __QUEUEARR_H_
#define MAX 100


template <typename T>
class QueueArr
{
private :
        T*Arr[MAX];
		int front;
		int rear;
        int size;
public :
        QueueArr();
        bool isEmpty() const;
        bool enqueue(const T& newEntry); 
        bool dequeue(T& frntEntry);  
        bool peekFront(T& frntEntry)  const;        
        ~Queue();        
};


/////////////////////////////////////////////////////////////////////////////////////////


/*
Function: QueueArr()
The constructor of the QueueArr class.


*/
template <typename T>
Queue<T>::QueueArr()
{
		front = 0;
		rear = -1;
        size = 0;
}
/////////////////////////////////////////////////////////////////////////////////////////


/*
Function: isEmpty
Sees whether this queue is empty.


Input: None.
Output: True if the queue is empty; otherwise false.
*/
template <typename T>
bool Queue<T>::isEmpty() const
{
        if(front > rear)
                return true;
        else
                return false;
}


/////////////////////////////////////////////////////////////////////////////////////////


/*Function:enqueue
Adds newEntry at the back of this queue.


Input: newEntry .
Output: True if the operation is successful; otherwise false.
*/


template <typename T>
bool Queue<T>::enqueue( const T& newEntry)
{
        if(size <= MAX)
        {
                Arr[++rear] = newEntry;
                size++;
                return true;
        }
        return false;


        
} // end enqueue




/////////////////////////////////////////////////////////////////////////////////////////////////////////


/*Function: dequeue
Removes the front of this queue. That is, removes the item that was added
earliest.


Input: None.
Output: True if the operation is successful; otherwise false.
*/


template <typename T>
bool Queue<T>:: dequeue(T& frntEntry)  
{
        if(isEmpty())
                return false;


        frntEntry = Arr[front];
        front++;
        
        size--;
    return true;


}


/////////////////////////////////////////////////////////////////////////////////////////


/*
Function: peekFront
gets the front of this queue. The operation does not modify the queue.


Input: None.
Output: The front of the queue.
return: flase if Queue is empty
*/
template <typename T>
bool Queue<T>:: peekFront(T& frntEntry) const 
{
        if(isEmpty())
                return false;

        frntEntry = Arr[front];
        return true;


}
///////////////////////////////////////////////////////////////////////////////////


template <typename T>
Queue<T>::~Queue()
{
}


#endif