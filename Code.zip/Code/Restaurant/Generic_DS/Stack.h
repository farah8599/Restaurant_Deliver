#ifndef __STACK_H_
#define __STACK_H_
#include "Node.h"

template <typename T>
class Stack
{
private:

	Node<T>* Top;
public :
	Stack();	
	bool isEmpty() const ;
	bool Push(const T& newEntry);
	bool Pop(T& topEntry);  
	bool Peek(T& topEntry)  const;	
	~Stack();
};
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
Stack<T>::Stack()
{
	Top=nullptr;

}
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
bool Stack<T>::isEmpty()const
{
	if(Top==nullptr)
		return true;
	else
		return false;
}
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
bool Stack<T>::Push(const T& newEntry)
{
	Node<T>* newNodePtr = new Node<T>(newEntry);
	// Insert the new node
	if (isEmpty())
		Top = newNodePtr; // The stack is empty
else
{
	newNodePtr->setNext(Top); // The stack was not empty
	Top=newNodePtr; // New node is at top
	}
	return true ;
} // end push

/////////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
bool Stack<T>::Pop(T& topEntry)
{
	if (isEmpty())
		return false;
	Node<T>* tempNodePtr = Top;
topEntry=Top->getItem();
	Top=Top->getNext();
	delete tempNodePtr;
	return true;
}//end pop

/////////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
bool Stack<T>::Peek(T& topEntry) const
{
	if (isEmpty())
		return false;
	topEntry=Top->getItem();
	return true;
}
///////////////////////////////////////////////////////////////////////////////////

template <typename T>
Stack<T>::~Stack()
{
}
#endif