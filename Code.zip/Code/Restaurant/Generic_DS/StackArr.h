#ifndef __STACKARR_H_
#define __STACKARR_H_
#define MAX 100

template <typename T>
class StackArr
{
private:

	int Top;
	T Array[MAX];
public :
	StackArr();	
	bool isEmpty() const ;
	bool isFull() const;
	bool Push(const T& newEntry);
	bool Pop(T& topEntry);  
	bool Peek(T& topEntry)  const;	
	~StackArr();
};
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
StackArr<T>::StackArr()
{
	Top=-1;

}
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
bool StackArr<T>::isEmpty()const
{
	if(Top==-1)
		return true;
	else
		return false;
}
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
bool StackArr<T>::isFull()const
{
	if(Top>=(MAX-1))
		return true;
	else
		return false;
}
/////////////////////////////////////////////////////////////////////////////////////////
template <typename T>
bool StackArr<T>::Push(const T& newEntry)
{
	if (isFull()) return false;
	Array[++Top]=newEntry;
	return true ;
} // end push

/////////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
bool StackArr<T>::Pop(T& topEntry)
{
	if (isEmpty())
		return false;
	topEntry=Array[Top--];
	return true;
}//end pop

/////////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
bool StackArr<T>::Peek(T& topEntry) const
{
	if (isEmpty())
		return false;
	topEntry=Array[Top];
	return true;
}
///////////////////////////////////////////////////////////////////////////////////

template <typename T>
StackArr<T>::~StackArr()
{
}
#endif