#include "Motorcycle.h"
#include <stdlib.h>

Motorcycle::Motorcycle()
{
}
Motorcycle::Motorcycle(int Id,ORD_TYPE OrderType,int S,REGION reg)
{
	status=IDLE;
	ReturnTS=-1;
	ID=Id;
	type=OrderType;
	//speed=(S/2)+(rand()%(S+1));   //Generate different speeds with mean value read from IP file
	speed=S;
	region=reg;
	RestTime=-1;
	RepairTime=-1;
}
void Motorcycle::setStatus(STATUS newStatus)
{
status=newStatus;
}

void Motorcycle::setReturnTS(int ReTS)
{
	ReturnTS=ReTS;
}
void Motorcycle::setRepairTime(int RepT)
{
	RepairTime=RepT;
}

void Motorcycle::setRestTime(int RT)
{
	RestTime=RT;
}
int Motorcycle::getReturnTS()
{
	return ReturnTS;
}
int Motorcycle::getRestTime()
{
	return RestTime;
}
int Motorcycle::getRepairTime()
{
	return RepairTime;
}

int Motorcycle::getSpeed()
{
	return speed;
}
Motorcycle::~Motorcycle()
{
}

void Motorcycle::incrementRestTime()
{
	RestTime++;
}
void Motorcycle::incrementRepairTime()
{
	RepairTime++;
}

STATUS Motorcycle::getStatus()
{
	return status;
}
Motorcycle* Motorcycle::getMinSpeed(Motorcycle *M1,Motorcycle *M2)
{
	if(M1->getSpeed() > M2->getSpeed())
		return M1;
	else 
		return M2;
}

ORD_TYPE Motorcycle::getType()
{
	return type;
}
int Motorcycle::getID()
{
	return ID;
}