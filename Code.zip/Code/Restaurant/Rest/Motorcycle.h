#ifndef __MOTORCYCLE_H_
#define __MOTORCYCLE_H_


#include "..\Defs.h"

#pragma once
class Motorcycle	
{
	int ID;
	ORD_TYPE type;	//for each order type there is a corresponding motorcycle type 
	int speed;		//meters it can move in one clock tick (in one timestep)
	REGION	region;	//region of the motorcycle
	STATUS	status;	//idle or in-service
	int ReturnTS;   //the time step at which the motorcycle becomes available again
	int RestTime;    //time needed for motorcycle to be assigned anothe order otherwise it will be damaged (to be incremented each timestep)
	int RepairTime;  //time needed for motorcycle to be repaired and back available if damaged (to be incremented each timestep)

public:
	Motorcycle();
	Motorcycle(int Id,ORD_TYPE OrderType,int S,REGION reg);
	void setStatus(STATUS newStatus);
	STATUS getStatus();
	void setReturnTS(int ReTS);
	int getReturnTS();
	virtual ~Motorcycle();
	int getSpeed();
	void incrementRestTime();
	void incrementRepairTime();
	void setRestTime(int RT);
	void setRepairTime(int RepT);
	int getRestTime();
	int getRepairTime();
	Motorcycle* getMinSpeed(Motorcycle* M1,Motorcycle* M2);  //returns a pointer to the motorcycle with minimum speed of two passed motorcycles
	ORD_TYPE getType();
	int getID();
};

#endif