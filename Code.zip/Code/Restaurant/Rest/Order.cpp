#include "Order.h"
#include <stdlib.h>
Order::Order(int id, ORD_TYPE r_Type, REGION r_region,int ATime,double Tot_Money,int Dist)
{
	ID = (id>0&&id<1000)?id:0;	//1<ID<999
	type = r_Type;
	Region = r_region;	
	ArrTime=ATime;
	totalMoney=Tot_Money;
	Distance=Dist;
	Priority=totalMoney+2*Distance-10*ArrTime;
	WaitTime=-1;
	TrafficFactor=rand()%2;
}
void Order::SetType(ORD_TYPE Ordertype)
{
	type=Ordertype;
}
Order::~Order()
{
}

int Order::GetID()
{
	return ID;
}


int Order::GetType() const
{
	return type;
}

REGION Order::GetRegion() const
{
	return Region;
}

void Order::SetDistance(int d)
{
	Distance = d>0?d:0;
}

int Order::GetDistance() const
{
	return Distance;
}

double Order::getPriority()const
{
	return Priority;
}
Order::Order()
{}

void Order:: SetMoney(double m)
{
	totalMoney = m;
}

double Order::getMoney()
{
	return totalMoney;
}
int Order::getArrTime()
{
	return ArrTime;
}

int Order::getWaitTime()
{
	return WaitTime;
}

void Order::incrementWaitTime()
{
	WaitTime++;
}
void Order::UpdatePriority()
{
	Priority=totalMoney+2*Distance-10*ArrTime;
}

bool Order::TrafficProblem()
{
	return TrafficFactor;
}

void Order::setFinishTime(int FT)
{
	FinishTime=FT;
}
void Order::setServTime(int ST)
{
	ServTime=ST;
}
int Order::getFinishTime()
{
	return FinishTime;
}

int Order::getServTime()
{
	return ServTime;
}