#ifndef __ORDER_H_
#define __ORDER_H_

#include "..\Defs.h"

class Order
{

protected:
	int ID;         //Each order has a unique ID (from 1 --> 999 )
	ORD_TYPE type;		//order type: Normal, Frozen, VIP
	REGION Region;  //Region of this order
	int Distance;	//The distance (in meters) between the order location and the resturant 
	                
	double totalMoney;	//Total order money

	int ArrTime, ServTime, FinishTime, WaitTime;	//arrival, service start, finish times , and waiting time (matters the most for Normal)
	double Priority;    //Priority of the Order (Calculated for all orders but matters only for VIP)
	int TrafficFactor;   //randomly generated factor either 0 or 1 that indicates whether the order includes traffic problems or not
	
public:
	Order(int id, ORD_TYPE r_Type, REGION r_region,int ATime,double Tot_Money,int Dist);
	virtual ~Order();

	int GetID();

	int GetType() const;
	double getPriority()const;
	REGION GetRegion() const;

	void SetDistance(int d);
	int GetDistance() const;

	void SetType(ORD_TYPE Ordertype);

      void SetMoney(double m);
       double getMoney();
       int getArrTime();
        int getWaitTime();
		int getServTime();
        Order(); //default constructor

		bool TrafficProblem();
		void setFinishTime(int FT);
		void setServTime(int ST);
		void incrementWaitTime();
		void UpdatePriority(); //updates the priority of promoted order (adds extra money)
		int getFinishTime();

	//
	// TODO: Add More Member Functions As Needed
	//

};

#endif