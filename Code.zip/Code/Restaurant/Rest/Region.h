#ifndef __REGION_H_
#define __REGION_H_


#include "..\Defs.h"
#include"..\Generic_DS\BagArr.h"
#include"..\Generic_DS\Queue.h"
#include"..\Generic_DS\List.h"
#include"..\Generic_DS\PQueue.h"
#include"Order.h"
#include"Motorcycle.h"

#pragma once
struct Region	
{
	Queue<Order*> FrozenOrders;
	List<Order*> NormalOrders;
	PQueue<Order*> VIPOrders;
	Queue<Order*> FamilyOrders;
	Queue<Order*> ComplaintOrders;
	PQueue<Motorcycle*> FrozenMotorcycles; 
	PQueue<Motorcycle*> NormalMotorcycles;
	PQueue<Motorcycle*> VIPMotorcycles;
	PQueue<Motorcycle*> InServiceNormalMotorcycles;
	PQueue<Motorcycle*> InServiceFrozenMotorcycles;
	PQueue<Motorcycle*> InServiceVIPMotorcycles;
	Queue<Motorcycle*> DamagedNormalMotorcycles;
	Queue<Motorcycle*> DamagedFrozenMotorcycles;
	Queue<Motorcycle*> DamagedVIPMotorcycles;
	int N,F,V;        //Number of Motorcycles of each type
	int FinishedN,FinishedF,FinishedV,FinishedFam;   //Number of Finished orders of each type
};
#endif

