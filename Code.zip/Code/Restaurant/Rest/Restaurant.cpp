#include <cstdlib>
#include <time.h>
#include <iostream>
#include <fstream>
using namespace std;

#include "Restaurant.h"
#include "..\Events\ArrivalEvent.h"
#include "..\Events\CancellationEvent.h"
#include "..\Events\PromotionEvent.h"
#include "..\Events\ComplaintEvent.h"


Restaurant::Restaurant() 
{
	for (int i=0;i<REG_CNT;i++)
	{
		Regions[i].FinishedF=0;
		Regions[i].FinishedV=0;
		Regions[i].FinishedN=0;
		Regions[i].FinishedFam=0;
	}


	pGUI = NULL;
}

void Restaurant::RunSimulation()
{
	pGUI = new GUI;
	PROG_MODE	mode = pGUI->getGUIMode();
		
	switch (mode)	
	{
	case MODE_INTR:
		InterActiveMode();
		break;
	case MODE_STEP:
		StepByStepMode();
		break;
	case MODE_SLNT:
		SilentMode();
		break;
	};

}

void Restaurant::Save()  //Saves O/P File
{
	ofstream OutFile;  //The Output file itself
	int WaitA=0, ServA=0; // Total waiting time and service time in each region 
	int WaitB=0, ServB=0;
	int WaitC=0, ServC=0;
	int WaitD=0, ServD=0;
	int RestaurantFinishedOrders=FinishedOrders.getlength(); //Total Finished Orders in restaurant
	int RestaurantMotoC;
	int RestN=0, RestF=0, RestV=0,RestFam=0; //Total orders of each type
	int RestWait,RestServ;      //Total waiting and service time for whole restaurant
	int RestMotoN=0,RestMotoF=0,RestMotoV=0;   //Total Motorcycles of each type

	pGUI->PrintMessage("Please Enter O/P filename:");
	string FileName=pGUI->GetString();
	OutFile.open(FileName+".txt");
	if (OutFile.is_open())

	{
		pGUI->PrintMessage("O/P file is Saved Successfully");
		OutFile<<"FT"<<'\t'<<"ID"<<'\t'<<"AT"<<'\t'<<"WT"<<'\t'<<"ST"<<'\n';
		Order* Ptr;
		while (FinishedOrders.peekFront(Ptr))
		{
			switch (Ptr->GetRegion())
			{
				case A_REG:
					WaitA+=(Ptr->getWaitTime());
					ServA+=(Ptr->getServTime());
					break;

				case B_REG:
					WaitB+=(Ptr->getWaitTime());
					ServB+=(Ptr->getServTime());
					break;

				case C_REG:
					WaitC+=(Ptr->getWaitTime());
					ServC+=(Ptr->getServTime());
					break;

				case D_REG:
					WaitD+=(Ptr->getWaitTime());
					ServD+=(Ptr->getServTime());
					break;

				default:
					break;
			}

			
			OutFile<< Ptr->getFinishTime()<<'\t'<<Ptr->GetID()<<'\t'<<Ptr->getArrTime()<<'\t'<<Ptr->getWaitTime()<<'\t'<<Ptr->getServTime()<<'\n';
			FinishedOrders.dequeue(Ptr);
			delete Ptr;

		}
		OutFile<<"��������������������������������������������������������������������"<<'\n';
		OutFile<<"��������������������������������������������������������������������"<<'\n';
		for (int i=0;i<REG_CNT;i++)

		{
			RestN+=Regions[i].FinishedN;
			RestF+=Regions[i].FinishedF;
			RestV+=Regions[i].FinishedV;
			RestFam+=Regions[i].FinishedFam;
			RestMotoN+=Regions[i].N;
			RestMotoF+=Regions[i].F;
			RestMotoV+=Regions[i].V;

			switch (i)
			{
				case 0:
					OutFile<<"Region A:"<<'\n';
					break;

				case 1:
					OutFile<<"Region B:"<<'\n';
					break;

				case 2:
					OutFile<<"Region C:"<<'\n';
					break;

				case 3:
					OutFile<<"Region D:"<<'\n';
					break;

				default:
					break;
			}



			int TotalOrders=Regions[i].FinishedF+Regions[i].FinishedN+Regions[i].FinishedV+Regions[i].FinishedFam;

			int TotalMotors=Regions[i].N+ Regions[i].F+Regions[i].V;

			OutFile<<"Orders: "<<TotalOrders<<"[Norm:"<<Regions[i].FinishedN<<", Froz:"<<Regions[i].FinishedF<<", VIP:"<<Regions[i].FinishedV<<", Fam:"<<Regions[i].FinishedFam<<"]"<<'\n';

			OutFile<<"MotorC: "<<TotalMotors<<"[Norm:"<<Regions[i].N<<", Froz:"<<Regions[i].F<<", VIP:"<<Regions[i].V<<"]"<<'\n';



			switch (i)
			{
				case 0:

					if(TotalOrders!=0)
						OutFile<<"Avg Wait:= "<<((double)WaitA/TotalOrders)<<",  Avg Serv= "<<((double)ServA/TotalOrders)<<'\n';

					else
						OutFile<<"Avg Wait:=0 ,  Avg Serv= 0"<<'\n';

					break;

				case 1:

					if(TotalOrders!=0)
						OutFile<<"Avg Wait:= "<<((double)WaitB/TotalOrders)<<",  Avg Serv= "<<((double)ServB/TotalOrders)<<'\n';

					else
						OutFile<<"Avg Wait:=0 ,  Avg Serv= 0"<<'\n';

					break;

				case 2:

					if(TotalOrders!=0)
						OutFile<<"Avg Wait:= "<<((double)WaitC/TotalOrders)<<",  Avg Serv= "<<((double)ServC/TotalOrders)<<'\n';

					else
						OutFile<<"Avg Wait:=0 ,  Avg Serv= 0"<<'\n';

					break;

				case 3:

					if(TotalOrders!=0)
						OutFile<<"Avg Wait:= "<<((double)WaitD/TotalOrders)<<",  Avg Serv= "<<((double)ServD/TotalOrders)<<'\n';

					else
						OutFile<<"Avg Wait:=0 ,  Avg Serv= 0"<<'\n';

					break;

				default:

					break;

			}
		}
		RestWait=WaitA+WaitB+WaitC+WaitD;
		RestServ=ServA+ServB+ServC+ServD;
		RestaurantMotoC=RestMotoF+RestMotoN+RestMotoV;
		OutFile<<'\n'<<"Restaurant:"<<'\n';
		OutFile<<"Orders: "<<RestaurantFinishedOrders<<"[Norm:"<<RestN<<", Froz:"<<RestF<<", VIP:"<<RestV<<", Fam:"<<RestFam<<"]"<<'\n';
		OutFile<<"MotorC: "<<RestaurantMotoC<<"[Norm:"<<RestMotoN<<", Froz:"<<RestMotoF<<", VIP:"<<RestMotoV<<"]"<<'\n';
		if(RestaurantFinishedOrders!=0)
						OutFile<<"Avg Wait:= "<<((double)RestWait/RestaurantFinishedOrders)<<",  Avg Serv= "<<((double)RestServ/RestaurantFinishedOrders)<<'\n';

					else
						OutFile<<"Avg Wait:=0 ,  Avg Serv= 0"<<'\n';
		OutFile.close();
	}

	else



	{

		pGUI->PrintMessage("Unable To Save File ");

		pGUI->waitForClick();

	}
	}


void Restaurant::Load()   //Loads I/P File
{
	ifstream InFile;   //The Load file itself
	char EventType,REG,TYP;
	int EventsCount,TS,ID,DST,MotoCSpeed;
	ORD_TYPE iTYP;
	REGION iREG;
	double EXMON,MON;
	pGUI->PrintMessage("Please Enter I/P filename:");
	string FileName=pGUI->GetString();
	InFile.open(FileName+".txt");
	if (InFile.is_open())
	{
	pGUI->PrintMessage("I/P file is Loaded Successfully");

	//Loads Rest and Repair times for Motorcycles 
	InFile >> RestTime >>RepairTime;
	//Loads Upper limits of Speeds of Motorcycles
	InFile >> SN >> SF >> SV;
	//Loads Number of Motorcycles of each type for each region seperately
	for (int i=0;i<REG_CNT;i++)
	InFile >> Regions[i].N >> Regions[i].F >>Regions[i].V;
	//Fill the motorcyles Queues
	for (int i=0;i<REG_CNT;i++)
		for (int j=0;j<Regions[i].N;j++)
		{
			//Loads speed
			InFile>>MotoCSpeed;
			//Checks the upper limit
			if (MotoCSpeed>SN)
				MotoCSpeed=SN;
			Motorcycle* NM=new Motorcycle(j,TYPE_NRM,MotoCSpeed,(REGION)i);
			Regions[i].NormalMotorcycles.enqueue(NM,NM->getSpeed());
		}
	for (int i=0;i<REG_CNT;i++)
		for (int j=0;j<Regions[i].F;j++)
		{
			//Loads speed
			InFile>>MotoCSpeed;
			//Checks the upper limit
			if (MotoCSpeed>SF)
				MotoCSpeed=SF;
			Motorcycle* FM=new Motorcycle(j,TYPE_FROZ,MotoCSpeed,(REGION)i);
			Regions[i].FrozenMotorcycles.enqueue(FM,FM->getSpeed());
		}
	for (int i=0;i<REG_CNT;i++)
		for (int j=0;j<Regions[i].V;j++)
		{
			//Loads speed
			InFile>>MotoCSpeed;
			//Checks the upper limit
			if (MotoCSpeed>SV)
				MotoCSpeed=SV;
			Motorcycle* VM=new Motorcycle(j,TYPE_VIP,MotoCSpeed,(REGION)i);
			Regions[i].VIPMotorcycles.enqueue(VM,VM->getSpeed());
		}
			
	//Loads AutoPromotion Limit and Number of Events
	InFile >> AutoS;
	InFile >> EventsCount;
	//Fill Events Queue
	for (int i=0;i<EventsCount;i++)
	{
		InFile >> EventType;
		switch (EventType) 
		{
		case 'R':
			InFile >>TS>>TYP>>ID>>DST>>MON>>REG;
			switch(TYP)
			{
			case 'N':
				iTYP=TYPE_NRM;
				break;
			case'F':
				iTYP=TYPE_FROZ;
				break;
			case 'V':
				iTYP=TYPE_VIP;
				break;
			case 'M':
				iTYP=TYPE_FAM;
				break;
			}
			switch (REG)
			{
			case 'A':
				iREG=A_REG;
				break;
			case 'B':
				iREG=B_REG;
				break;
			case 'C':
				iREG=C_REG;
				break;
			case 'D':
				iREG=D_REG;
				break;
			}
				
		AddEvent(new ArrivalEvent(TS,ID,iTYP,iREG,DST,MON));
			break;
		case 'X':
			InFile >>TS>>ID;
        AddEvent(new CancellationEvent(TS,ID));
			break;
		case 'P':
			InFile >>TS>>ID>>EXMON;
			AddEvent(new PromotionEvent(TS,ID,EXMON));
			break;
		case 'C':
			InFile >>TS>>ID;
			AddEvent(new ComplaintEvent(TS, ID));
			break;
		}
	}
	
	InFile.close();
	}
	else
	{
		pGUI->PrintMessage("File is not found..");
		pGUI->waitForClick();
	}
}


//////////////////////////////////  Event handling functions   /////////////////////////////
void Restaurant::AddEvent(Event* pE)	//adds a new event to the queue of events
{
	EventsQueue.enqueue(pE);
}

//Executes ALL events that should take place at current timestep
void Restaurant::ExecuteEvents()
{
	Event *pE;
	while( EventsQueue.peekFront(pE) )	//as long as there are more events
	{
		if(pE->getEventTime() > CurrentTimeStep )	//no more events at current time
			return;
		pE->Execute(this);
		EventsQueue.dequeue(pE);	//remove event from the queue
		delete pE;		//deallocate event object from memory
	}

}


Restaurant::~Restaurant()
{
		delete pGUI;
}

////////////////////////////////////////////////////////////////////////////////
/// ==> 
///  GUI Modes-related functions.

//InterActive Mode
void Restaurant::InterActiveMode()
{
	Load();
 CurrentTimeStep = 0;
string DeliverA="",DeliverB="",DeliverC="",DeliverD="";  //messages to print for delivered orders at each timestep
	//as long as events queue is not empty yet or active orders are not all delivered yet
	while(!EventsQueue.isEmpty()||!AllDelivered()||!AllFinished()||!AllReturned())
	{
		PrintInfo(DeliverA,DeliverB,DeliverC,DeliverD);     //Print Info
		BackIdle();      //Return Motorcycles
		RepairMotorcycles();            //Return repaired Motorcycles
		//Incrementing waiting time for all orders and repair time for all motorcycles:
		incrementWaitTime();
		incrementRepairTime();
		Deliver(DeliverA,DeliverB,DeliverC,DeliverD);
		returnOrder(DeliverA,DeliverB,DeliverC,DeliverD);
		AutoPromote();   //Auto promotion explicitly
		//increment rest time (after delivery because it starts from 0)
		incrementRestTime();
		pGUI->waitForClick();
		CurrentTimeStep++;	//advance timestep
		ExecuteEvents();	//execute all events at current time step
		UpdateDrawingList();
		pGUI->UpdateInterface();
		}        
	pGUI->PrintMessage("simulation is done, click to END program");
	pGUI->waitForClick();
}

//Step-By-Step Mode
void Restaurant::StepByStepMode()
{
	Load();
 CurrentTimeStep = 0;
string DeliverA="",DeliverB="",DeliverC="",DeliverD="";  //messages to print for delivered orders at each timestep
	//as long as events queue is not empty yet or active orders are not all delivered yet
		while(!EventsQueue.isEmpty()||!AllDelivered()||!AllFinished()||!AllReturned())
	{
		PrintInfo(DeliverA,DeliverB,DeliverC,DeliverD);     //Print Info
		BackIdle();      //Return Motorcycles
		RepairMotorcycles();            //Return repaired Motorcycles
		//Incrementing waiting time for all orders and repair time for all motorcycles:
		incrementWaitTime();
		incrementRepairTime();
		Deliver(DeliverA,DeliverB,DeliverC,DeliverD);
		returnOrder(DeliverA,DeliverB,DeliverC,DeliverD);
			AutoPromote();   //Auto promotion explicitly
		//increment rest time (after delivery because it starts from 0)
		incrementRestTime();
		Sleep(1000);
		CurrentTimeStep++;	//advance timestep
		ExecuteEvents();	//execute all events at current time step
		UpdateDrawingList();
		pGUI->UpdateInterface();
		}        
	pGUI->PrintMessage("simulation is done, click to END program");
	pGUI->waitForClick();
}

//Silent Mode
void Restaurant::SilentMode()
{
	Load();
	CurrentTimeStep = 0;
string DeliverA="",DeliverB="",DeliverC="",DeliverD="";  //messages to print for delivered orders at each timestep
	//as long as events queue is not empty yet or active orders are not all delivered yet
	while(!EventsQueue.isEmpty()||!AllDelivered()||!AllFinished()||!AllReturned())
	{
		BackIdle();      //Return Motorcycles
		RepairMotorcycles();            //Return repaired Motorcycles
		//Incrementing waiting time for all orders and repair time for all motorcycles:
		incrementWaitTime();
		incrementRepairTime();
		Deliver(DeliverA,DeliverB,DeliverC,DeliverD);
		returnOrder(DeliverA,DeliverB,DeliverC,DeliverD);
		AutoPromote();   //Auto promotion explicitly
		//increment rest time (after delivery because it starts from 0)
		incrementRestTime();
		CurrentTimeStep++;	//advance timestep
		ExecuteEvents();	//execute all events at current time step
		}        
}

/// ==> added functions
Region* Restaurant::getRegions()
{
	return Regions;
}

int Restaurant::getAutoS()
{
	return AutoS;
}
 void Restaurant::AddtoOrdersList(Order* po)
 {
	 
	 if (po->GetType()==TYPE_NRM)
		 Regions[po->GetRegion()].NormalOrders.insert(po);
	 else if (po->GetType()==TYPE_FROZ)
		  Regions[po->GetRegion()].FrozenOrders.enqueue(po);
	 else if (po->GetType()==TYPE_VIP)
		  Regions[po->GetRegion()].VIPOrders.enqueue(po,po->getPriority());
	 else if (po->GetType()==TYPE_FAM)
		  Regions[po->GetRegion()].FamilyOrders.enqueue(po);
	 return;
 }

 void Restaurant::AutoPromote()
 {
	 for (int i = 0; i < REG_CNT; i++)
	 {
	 Order* Ord=Regions[i].NormalOrders.getEntry(0);
		while (Ord!=NULL && Ord->getWaitTime() >= AutoS)
		{
			Ord->SetType(TYPE_VIP);
			Regions[i].NormalOrders.remove(0);
			Regions[i].VIPOrders.enqueue(Ord,Ord->getPriority());
			Ord=Regions[i].NormalOrders.getEntry(0);
		}
	 }
 }

 void Restaurant::UpdateDrawingList()
 {
	 int NCount,VCount,FCount,FamCount,ComCount;
	 Order* const* NOrders,*const*VOrders,*const*FOrders,*const*FamOrders,*const*ComOrders;
	 //Let`s reset the drawing list before drawing orders
		pGUI->ResetDrawingList();

		//Let's draw all arrived orders by passing them to the GUI to draw
		for (int i=0;i<REG_CNT;i++)
		{
			 NOrders=Regions[i].NormalOrders.toArray();
			 VOrders=Regions[i].VIPOrders.toArray();
			 FOrders=Regions[i].FrozenOrders.toArray();
			 FamOrders=Regions[i].FamilyOrders.toArray();
			 ComOrders = Regions[i].ComplaintOrders.toArray();
             ComCount = Regions[i].ComplaintOrders.getlength();
			 NCount=Regions[i].NormalOrders.getlength();
			 VCount=Regions[i].VIPOrders.getlength();
			 FCount=Regions[i].FrozenOrders.getlength();
			 FamCount=Regions[i].FamilyOrders.getlength();
			 for (int k=0;k<VCount;k++)
				 pGUI->AddOrderForDrawing(VOrders[k]);
			 for (int m=0;m<FCount;m++)
				 pGUI->AddOrderForDrawing(FOrders[m]);
			 for (int j=0;j<NCount;j++)
				 pGUI->AddOrderForDrawing(NOrders[j]);
			 for (int l=0;l<FamCount;l++)
				 pGUI->AddOrderForDrawing(FamOrders[l]);
			 for (int n = 0; n < ComCount; n++)
				 pGUI->AddOrderForDrawing(ComOrders[n]);
			 
		}
 }
			
		
	void Restaurant::PrintInfo(string DeliverA,string DeliverB,string DeliverC,string DeliverD)
	{
		pGUI->PrintMessage("");
		for (int i=0;i<REG_CNT;i++)
		{
			switch (i)
			{
			case 0:
				pGUI->PrintMessage("Region A: NMotoC "+to_string(Regions[i].NormalMotorcycles.getlength())+" FMotoC "+to_string(Regions[i].FrozenMotorcycles.getlength())+" VMotoC "+to_string(Regions[i].VIPMotorcycles.getlength())+" NOrders "+to_string(Regions[i].NormalOrders.getlength())+" FOrders "+to_string(Regions[i].FrozenOrders.getlength())+" VOrders "+to_string(Regions[i].VIPOrders.getlength())+" FamOrders "+to_string(Regions[i].FamilyOrders.getlength())+" ServedN "+to_string(Regions[i].FinishedN)+" ServedF "+to_string(Regions[i].FinishedF)+" ServedV "+to_string(Regions[i].FinishedV)+" ServedFam "+to_string(Regions[i].FinishedFam)+DeliverA,(REGION)i);
				break;
			case 1:
				pGUI->PrintMessage("Region B: NMotoC "+to_string(Regions[i].NormalMotorcycles.getlength())+" FMotoC "+to_string(Regions[i].FrozenMotorcycles.getlength())+" VMotoC "+to_string(Regions[i].VIPMotorcycles.getlength())+" NOrders "+to_string(Regions[i].NormalOrders.getlength())+" FOrders "+to_string(Regions[i].FrozenOrders.getlength())+" VOrders "+to_string(Regions[i].VIPOrders.getlength())+" FamOrders "+to_string(Regions[i].FamilyOrders.getlength())+" ServedN "+to_string(Regions[i].FinishedN)+" ServedF "+to_string(Regions[i].FinishedF)+" ServedV "+to_string(Regions[i].FinishedV)+" ServedFam "+to_string(Regions[i].FinishedFam)+DeliverB,(REGION)i);
				break;
			case 2:
				pGUI->PrintMessage("Region C: NMotoC "+to_string(Regions[i].NormalMotorcycles.getlength())+" FMotoC "+to_string(Regions[i].FrozenMotorcycles.getlength())+" VMotoC "+to_string(Regions[i].VIPMotorcycles.getlength())+" NOrders "+to_string(Regions[i].NormalOrders.getlength())+" FOrders "+to_string(Regions[i].FrozenOrders.getlength())+" VOrders "+to_string(Regions[i].VIPOrders.getlength())+" FamOrders "+to_string(Regions[i].FamilyOrders.getlength())+" ServedN "+to_string(Regions[i].FinishedN)+" ServedF "+to_string(Regions[i].FinishedF)+" ServedV "+to_string(Regions[i].FinishedV)+" ServedFam "+to_string(Regions[i].FinishedFam)+DeliverC,(REGION)i);
				break;
			case 3:
				pGUI->PrintMessage("Region D: NMotoC "+to_string(Regions[i].NormalMotorcycles.getlength())+" FMotoC "+to_string(Regions[i].FrozenMotorcycles.getlength())+" VMotoC "+to_string(Regions[i].VIPMotorcycles.getlength())+" NOrders "+to_string(Regions[i].NormalOrders.getlength())+" FOrders "+to_string(Regions[i].FrozenOrders.getlength())+" VOrders "+to_string(Regions[i].VIPOrders.getlength())+" FamOrders "+to_string(Regions[i].FamilyOrders.getlength())+" ServedN "+to_string(Regions[i].FinishedN)+" ServedF "+to_string(Regions[i].FinishedF)+" ServedV "+to_string(Regions[i].FinishedV)+" ServedFam "+to_string(Regions[i].FinishedFam)+DeliverD,(REGION)i);
				break;
			default:
				break;
			}
		}
		pGUI->PrintMessage(CurrentTimeStep);
	}

	void Restaurant::incrementWaitTime()
	{
		 int NCount,VCount,FCount,FamCount;
 Order*const* NOrders,*const*VOrders,*const*FOrders,*const*FamOrders;
	 //Let`s increment wait time

		for (int i=0;i<REG_CNT;i++)
		{
			 NOrders=Regions[i].NormalOrders.toArray();
			 VOrders=Regions[i].VIPOrders.toArray();
			 FOrders=Regions[i].FrozenOrders.toArray();
			 FamOrders=Regions[i].FamilyOrders.toArray();
			 NCount=Regions[i].NormalOrders.getlength();
			 VCount=Regions[i].VIPOrders.getlength();
			 FCount=Regions[i].FrozenOrders.getlength();
			 FamCount=Regions[i].FamilyOrders.getlength();
			 for (int k=0;k<VCount;k++)
				 VOrders[k]->incrementWaitTime();
			 for (int m=0;m<FCount;m++)
				 FOrders[m]->incrementWaitTime();
			 for (int j=0;j<NCount;j++)
				 NOrders[j]->incrementWaitTime();
			 for (int l=0;l<FamCount;l++)
				 FamOrders[l]->incrementWaitTime();
			 
		}
	}

	void Restaurant::incrementRestTime()
	{
		 int NCount,VCount,FCount;
 Motorcycle*const* NMotorcycles,*const*VMotorcycles,*const*FMotorcycles;
	 //Let`s increment rest time

		for (int i=0;i<REG_CNT;i++)
		{
			 NMotorcycles=Regions[i].NormalMotorcycles.toArray();
			 VMotorcycles=Regions[i].VIPMotorcycles.toArray();
			 FMotorcycles=Regions[i].FrozenMotorcycles.toArray();
			 NCount=Regions[i].NormalMotorcycles.getlength();
			 VCount=Regions[i].VIPMotorcycles.getlength();
			 FCount=Regions[i].FrozenMotorcycles.getlength();
			 for (int k=0;k<VCount;k++)
				 if (VMotorcycles[k]->getRestTime()>=0)
				 VMotorcycles[k]->incrementRestTime();
			 for (int m=0;m<FCount;m++)
				 if (FMotorcycles[m]->getRestTime()>=0)
				 FMotorcycles[m]->incrementRestTime();
			 for (int j=0;j<NCount;j++)
				 if (NMotorcycles[j]->getRestTime()>=0)
				 NMotorcycles[j]->incrementRestTime();
			 
		}
	}

	void Restaurant::incrementRepairTime()
	{
		 int NCount,VCount,FCount;
 Motorcycle*const* NMotorcycles,*const*VMotorcycles,*const*FMotorcycles;
	 //Let`s increment repair time

		for (int i=0;i<REG_CNT;i++)
		{
			 NMotorcycles=Regions[i].DamagedNormalMotorcycles.toArray();
			 VMotorcycles=Regions[i].DamagedVIPMotorcycles.toArray();
			 FMotorcycles=Regions[i].DamagedFrozenMotorcycles.toArray();
			 NCount=Regions[i].DamagedNormalMotorcycles.getlength();
			 VCount=Regions[i].DamagedVIPMotorcycles.getlength();
			 FCount=Regions[i].DamagedFrozenMotorcycles.getlength();
			 for (int k=0;k<VCount;k++)
				 VMotorcycles[k]->incrementRepairTime();
			 for (int m=0;m<FCount;m++)
				 FMotorcycles[m]->incrementRepairTime();
			 for (int j=0;j<NCount;j++)
				 NMotorcycles[j]->incrementRepairTime();
			 
		}
	}
	void Restaurant::Deliver(string& DeliverA,string& DeliverB,string& DeliverC,string& DeliverD)
	{
		DeliverA="";
		DeliverB="";
		DeliverC="";
		DeliverD="";
		Order* pOrd;
		Motorcycle* pMoto=NULL,*pMotoXX=NULL;
		Motorcycle* pSlower;
		//This is just for phase 1
		for (int i=0;i<REG_CNT;i++)
		{
			while(!Regions[i].VIPOrders.isEmpty())
			{
			 if(!Regions[i].VIPMotorcycles.isEmpty())
			{
				Regions[i].VIPMotorcycles.dequeue(pMoto);
				Regions[i].VIPOrders.dequeue(pOrd);
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedV++;
				Regions[i].InServiceVIPMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}

			 }
			 else if (!Regions[i].NormalMotorcycles.isEmpty())
			{
				Regions[i].NormalMotorcycles.dequeue(pMoto);
				Regions[i].VIPOrders.dequeue(pOrd);
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedV++;
				Regions[i].InServiceNormalMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  N"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  N"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  N"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  N"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
			 }
			 else if (!Regions[i].FrozenMotorcycles.isEmpty())
			{
				Regions[i].FrozenMotorcycles.dequeue(pMoto);
				Regions[i].VIPOrders.dequeue(pOrd);
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedV++;
				Regions[i].InServiceFrozenMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  F"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  F"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  F"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  F"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
			 }
			 else
				 break;
			 
			}
			while(!Regions[i].FamilyOrders.isEmpty())
{
				if(!Regions[i].NormalMotorcycles.isEmpty())
				{
					if (Regions[i].NormalMotorcycles.getlength()>=2)
					{
					Regions[i].NormalMotorcycles.dequeue(pMoto);
					Regions[i].NormalMotorcycles.dequeue(pMotoXX);
					}

					else if(!Regions[i].VIPMotorcycles.isEmpty())
					{
					Regions[i].NormalMotorcycles.dequeue(pMoto);
					Regions[i].VIPMotorcycles.dequeue(pMotoXX);
					}
				}
				else if(Regions[i].VIPMotorcycles.getlength()>=2)
				{
					Regions[i].VIPMotorcycles.dequeue(pMoto);
					Regions[i].VIPMotorcycles.dequeue(pMotoXX);
				}
				if(pMoto && pMotoXX)
				{
					pSlower=pMoto->getMinSpeed(pMoto,pMotoXX);
					Regions[i].FamilyOrders.dequeue(pOrd);
					pMoto->setStatus(SERV);
					pMotoXX->setStatus(SERV);
					pMoto->setReturnTS(CurrentTimeStep+(2*pOrd->GetDistance()/pMoto->getSpeed()));
					pMotoXX->setReturnTS(CurrentTimeStep+(2*pOrd->GetDistance()/pMotoXX->getSpeed()));
					pOrd->setFinishTime((CurrentTimeStep+(pOrd->GetDistance())/(pSlower->getSpeed())));
					pOrd->setServTime((pOrd->GetDistance())/(pSlower->getSpeed()));

						if (pOrd->TrafficProblem())
						{
							pMoto->setRestTime(0);
							pMotoXX->setRestTime(0);
						}
						if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
							pMoto->setStatus(DMG);
						if (pMotoXX->getRestTime()!=-1 && pMotoXX->getRestTime()<RestTime)
							pMotoXX->setStatus(DMG);
						FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
						Regions[i].FinishedFam++;

						if(pMoto->getType() == TYPE_NRM)
						{
							Regions[i].InServiceNormalMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());

							switch(i)
				{
				case 0:
					DeliverA+="  N"+to_string(pMoto->getID())+"-";
						break;
				case 1:
					DeliverB+="  N"+to_string(pMoto->getID())+"-";
						break;
				case 2:
					DeliverC+="  N"+to_string(pMoto->getID())+"-";
						break;
				case 3:
					DeliverD+="  N"+to_string(pMoto->getID())+"-";
						break;
				default:
					break;
				}
						}
						else 
						{
							Regions[i].InServiceVIPMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
							
							switch(i)
				{
				case 0:
					DeliverA+="  V"+to_string(pMoto->getID())+"-";
						break;
				case 1:
					DeliverB+="  V"+to_string(pMoto->getID())+"-";
						break;
				case 2:
					DeliverC+="  V"+to_string(pMoto->getID())+"-";
						break;
				case 3:
					DeliverD+="  V"+to_string(pMoto->getID())+"-";
						break;
				default:
					break;
				}
						}
						if(pMotoXX->getType()==TYPE_NRM)
						{
							Regions[i].InServiceNormalMotorcycles.enqueue(pMotoXX,-pMotoXX->getReturnTS());
							
							switch(i)
				{
				case 0:
					DeliverA+="N"+to_string(pMotoXX->getID());
						break;
				case 1:
					DeliverB+="N"+to_string(pMotoXX->getID());
						break;
				case 2:
					DeliverC+="N"+to_string(pMotoXX->getID());
						break;
				case 3:
					DeliverD+="N"+to_string(pMotoXX->getID());
						break;
				default:
					break;
				}
						}
						else
						{
							Regions[i].InServiceVIPMotorcycles.enqueue(pMotoXX,-pMotoXX->getReturnTS());
									
							switch(i)
				{
				case 0:
					DeliverA+="V"+to_string(pMotoXX->getID());
						break;
				case 1:
					DeliverB+="V"+to_string(pMotoXX->getID());
						break;
				case 2:
					DeliverC+="V"+to_string(pMotoXX->getID());
						break;
				case 3:
					DeliverD+="V"+to_string(pMotoXX->getID());
						break;
				default:
					break;
				}
						}


				switch(i)
				{
				case 0:
					DeliverA+="(Fam"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="(Fam"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="(Fam"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="(Fam"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}	
				}
				else 
					break;
			}
			 while(!Regions[i].FrozenOrders.isEmpty())
			{
			if (!Regions[i].FrozenMotorcycles.isEmpty())
			{
				Regions[i].FrozenMotorcycles.dequeue(pMoto);
				Regions[i].FrozenOrders.dequeue(pOrd);
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedF++;
				Regions[i].InServiceFrozenMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  F"+to_string(pMoto->getID())+"(F"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  F"+to_string(pMoto->getID())+"(F"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  F"+to_string(pMoto->getID())+"(F"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  F"+to_string(pMoto->getID())+"(F"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
			 }
			else
				break;
			 }
			 while(!Regions[i].NormalOrders.isEmpty())
			{
			 
			 if (!Regions[i].NormalMotorcycles.isEmpty())
			{
				Regions[i].NormalMotorcycles.dequeue(pMoto);
				pOrd=Regions[i].NormalOrders.getEntry(0);
				Regions[i].NormalOrders.remove();
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedN++;
				Regions[i].InServiceNormalMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  N"+to_string(pMoto->getID())+"(N"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  N"+to_string(pMoto->getID())+"(N"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  N"+to_string(pMoto->getID())+"(N"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  N"+to_string(pMoto->getID())+"(N"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
			 }
			 else if(!Regions[i].VIPMotorcycles.isEmpty())
			{
				Regions[i].VIPMotorcycles.dequeue(pMoto);
				pOrd=Regions[i].NormalOrders.getEntry(0);
				Regions[i].NormalOrders.remove();
				pMoto->setStatus(SERV);
				pMoto->setReturnTS(CurrentTimeStep+((2*pOrd->GetDistance())/(pMoto->getSpeed())));
				pOrd->setFinishTime((CurrentTimeStep+((pOrd->GetDistance())/(pMoto->getSpeed()))));
				pOrd->setServTime((pOrd->GetDistance())/(pMoto->getSpeed()));
				if (pOrd->TrafficProblem())
				pMoto->setRestTime(0);
				if (pMoto->getRestTime()!=-1 && pMoto->getRestTime()<RestTime)
					pMoto->setStatus(DMG);
				FinishedOrders.enqueue(pOrd,-pOrd->getFinishTime());
				Regions[i].FinishedN++;
				Regions[i].InServiceVIPMotorcycles.enqueue(pMoto,-pMoto->getReturnTS());
				switch(i)
				{
				case 0:
					DeliverA+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  V"+to_string(pMoto->getID())+"(V"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
			 }
			 else
				 break;
			 }
			 }
			 }

	bool Restaurant::AllDelivered()
	{
		for (int i=0;i<REG_CNT;i++)
			if (!Regions[i].NormalOrders.isEmpty()||!Regions[i].FrozenOrders.isEmpty()||!Regions[i].VIPOrders.isEmpty())
				return false;

		return true;
	}

	bool Restaurant::AllFinished()
	{
		Order*const* Orders = FinishedOrders.toArray();
		if (FinishedOrders.getlength()==0)
			return true;
		if (Orders[FinishedOrders.getlength()-1]->getFinishTime()<CurrentTimeStep)
			return true;
		else
			return false;
	}

	void Restaurant::BackIdle()
	{
		Motorcycle* NMoto,*FMoto,*VMoto;
		 for (int i = 0; i < REG_CNT; i++)
	 {
	 
		while (Regions[i].InServiceNormalMotorcycles.peekFront(NMoto) && NMoto->getReturnTS() <= CurrentTimeStep)
		{
			Regions[i].InServiceNormalMotorcycles.dequeue(NMoto);
			NMoto->setReturnTS(-1);
			if(NMoto->getStatus()==SERV)
			{
			Regions[i].NormalMotorcycles.enqueue(NMoto,NMoto->getSpeed());
	        NMoto->setStatus(IDLE);
			}
			else if (NMoto->getStatus()==DMG)
			Regions[i].DamagedNormalMotorcycles.enqueue(NMoto);
		}
		while (Regions[i].InServiceFrozenMotorcycles.peekFront(FMoto) && FMoto->getReturnTS() <= CurrentTimeStep )
		{
			Regions[i].InServiceFrozenMotorcycles.dequeue(FMoto);
			FMoto->setReturnTS(-1);
			if(FMoto->getStatus()==SERV)
			{
			Regions[i].FrozenMotorcycles.enqueue(FMoto,FMoto->getSpeed());
	        FMoto->setStatus(IDLE);
			}
			else if (FMoto->getStatus()==DMG)
			Regions[i].DamagedFrozenMotorcycles.enqueue(FMoto);
		}
		while (Regions[i].InServiceVIPMotorcycles.peekFront(VMoto)&& VMoto->getReturnTS() <= CurrentTimeStep )
		{
			Regions[i].InServiceVIPMotorcycles.dequeue(VMoto);
			VMoto->setReturnTS(-1);
			if(VMoto->getStatus()==SERV)
			{
			Regions[i].VIPMotorcycles.enqueue(VMoto,VMoto->getSpeed());
	        VMoto->setStatus(IDLE);
			}
			else if (VMoto->getStatus()==DMG)
				Regions[i].DamagedVIPMotorcycles.enqueue(VMoto);
		}
		 }
	}

	void Restaurant::RepairMotorcycles()
	{
		Motorcycle* NMoto,*FMoto,*VMoto;
		 for (int i = 0; i < REG_CNT; i++)
	 {
		while ( Regions[i].DamagedNormalMotorcycles.peekFront(NMoto) && NMoto->getRepairTime() >= RepairTime)
		{
			Regions[i].DamagedNormalMotorcycles.dequeue(NMoto);
			Regions[i].NormalMotorcycles.enqueue(NMoto,NMoto->getSpeed());
			NMoto->setRepairTime(-1);
			NMoto->setStatus(IDLE);
		}
		while (Regions[i].DamagedFrozenMotorcycles.peekFront(FMoto) && FMoto->getRepairTime() >= RepairTime)
		{
			Regions[i].DamagedFrozenMotorcycles.dequeue(FMoto);
			Regions[i].FrozenMotorcycles.enqueue(FMoto,FMoto->getSpeed());
			FMoto->setRepairTime(-1);
			FMoto->setStatus(IDLE);
		}
		while ( Regions[i].DamagedVIPMotorcycles.peekFront(VMoto) && VMoto->getRepairTime() >= RepairTime)
		{
			Regions[i].DamagedVIPMotorcycles.dequeue(VMoto);
			Regions[i].VIPMotorcycles.enqueue(VMoto,VMoto->getSpeed());
			VMoto->setRepairTime(-1);
			VMoto->setStatus(IDLE);
		}
		 }
	}

	void Restaurant::Complain(int ID)
	{
		Order*const*Orders = FinishedOrders.toArray();
		for (int i = 0; i < FinishedOrders.getlength(); i++)
		{
			if (Orders[i]->GetID() == ID)
			{
				if (Orders[i]->GetType() == TYPE_VIP && Orders[i]->getFinishTime()<=CurrentTimeStep)
				{
					REGION R = Orders[i]->GetRegion();
					List<Order*> templist;
					Order* pOrder;
					Order* CompOrder;
					int length = FinishedOrders.getlength();
					for (int j = 0; j < length; j++)
					{
						FinishedOrders.dequeue(pOrder);
						templist.insert(pOrder);
					}
					CompOrder = templist.getEntry(i);
					templist.remove(i);
					CompOrder->SetType(TYPE_COMP);
					if (R == A_REG)
					{
						Regions[0].ComplaintOrders.enqueue(CompOrder);
						Regions[0].FinishedV--;
					}
						
					else if (R == B_REG)
					{
						Regions[1].ComplaintOrders.enqueue(CompOrder);
						Regions[1].FinishedV--;
					}
						

					else if (R == C_REG)
					{
						Regions[2].ComplaintOrders.enqueue(CompOrder);
						Regions[2].FinishedV--;
					}

					else if (R == D_REG)
					{
						Regions[3].ComplaintOrders.enqueue(CompOrder);
						Regions[3].FinishedV--;
					}
				
					for (int j = length-2;j>=0; j--)
					{
						pOrder = templist.getEntry(j);
						if (pOrder)
							FinishedOrders.enqueue(pOrder, -(pOrder->getFinishTime()));
					}
					break;
				}
			}
		}
	}

	void Restaurant::returnOrder(string& DeliverA,string& DeliverB,string& DeliverC,string& DeliverD)
	{
		Order* pOrd;
		Motorcycle* pMoto = NULL, *pMotoXX = NULL;
		for (int i = 0; i < REG_CNT;i++)
		{
			while (!Regions[i].ComplaintOrders.isEmpty())
			{
				if (!Regions[i].VIPMotorcycles.isEmpty())
				{
					Regions[i].VIPMotorcycles.dequeue(pMoto);
					Regions[i].ComplaintOrders.dequeue(pOrd);
					switch(i)
				{
				case 0:
					DeliverA+="  V"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  V"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  V"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  V"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
					pMoto->setStatus(SERV);
					pMoto->setReturnTS(CurrentTimeStep + ((2 * pOrd->GetDistance()) / (pMoto->getSpeed())));
					if (pOrd->TrafficProblem())
						pMoto->setRestTime(0);
					if (pMoto->getRestTime() != -1 && pMoto->getRestTime() < RestTime)
						pMoto->setStatus(DMG);
					Regions[i].InServiceVIPMotorcycles.enqueue(pMoto, -pMoto->getReturnTS());
				}
				else if (!Regions[i].NormalMotorcycles.isEmpty())
				{
					Regions[i].NormalMotorcycles.dequeue(pMoto);
					Regions[i].ComplaintOrders.dequeue(pOrd);
					switch(i)
				{
				case 0:
					DeliverA+="  N"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  N"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  N"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  N"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
					pMoto->setStatus(SERV);
					pMoto->setReturnTS(CurrentTimeStep + ((2 * pOrd->GetDistance()) / (pMoto->getSpeed())));
					if (pOrd->TrafficProblem())
						pMoto->setRestTime(0);
					if (pMoto->getRestTime() != -1 && pMoto->getRestTime() < RestTime)
						pMoto->setStatus(DMG);
					Regions[i].InServiceNormalMotorcycles.enqueue(pMoto, -pMoto->getReturnTS());
				}
				else if (!Regions[i].FrozenMotorcycles.isEmpty())
				{
					Regions[i].FrozenMotorcycles.dequeue(pMoto);
					Regions[i].ComplaintOrders.dequeue(pOrd);
					switch(i)
				{
				case 0:
					DeliverA+="  F"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 1:
					DeliverB+="  F"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 2:
					DeliverC+="  F"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				case 3:
					DeliverD+="  F"+to_string(pMoto->getID())+"(C"+to_string(pOrd->GetID())+")";
						break;
				default:
					break;
				}
					pMoto->setStatus(SERV);
					pMoto->setReturnTS(CurrentTimeStep + ((2 * pOrd->GetDistance()) / (pMoto->getSpeed())));
					if (pOrd->TrafficProblem())
						pMoto->setRestTime(0);
					if (pMoto->getRestTime() != -1 && pMoto->getRestTime() < RestTime)
						pMoto->setStatus(DMG);
					Regions[i].InServiceFrozenMotorcycles.enqueue(pMoto, -pMoto->getReturnTS());
				}
				else
					break;
			}
		}
	}

	bool Restaurant::AllReturned()
	{
		for (int i=0;i<REG_CNT;i++)
			if (!Regions[i].ComplaintOrders.isEmpty())
				return false;

		return true;
	}