#ifndef __RESTAURANT_H_
#define __RESTAURANT_H_

#include "..\Defs.h"
#include "..\CMUgraphicsLib\CMUgraphics.h"
#include "..\GUI\GUI.h"
#include "..\Generic_DS\Queue.h"
#include "..\Generic_DS\PQueue.h"
#include "..\Events\Event.h"
#include "Region.h"


#include "Order.h"

// it is the maestro of the project
class Restaurant  
{	
private:
	GUI *pGUI;
	Queue<Event*> EventsQueue;	//Queue of all events that will be loaded from file
	Region Regions[REG_CNT];     //Array of regions
	PQueue <Order*> FinishedOrders;  //Queue of all finished orders, ordered with finish time
	
	int SN,SF,SV,AutoS;    //Speeds of Motorcyles and AutoPromotion
    int RestTime;    //time needed for motorcycle to be assigned anothe order otherwise it will be damaged (loaded from IP file)
	int RepairTime;  //time needed for motorcycle to be repaired and back available if damaged (loaded from IP file)
	int CurrentTimeStep;

public:
	
	Restaurant();
	~Restaurant();
	void AddEvent(Event* pE);	//adds a new event to the queue of events
	void ExecuteEvents();	//executes all events at current timestep
	void RunSimulation();
	void Load();                        //Loads I/P File
	void Save();                        //Generates O/P File
	void InterActiveMode();
	void SilentMode();
	void StepByStepMode();
	void PrintInfo(string DeliverA,string DeliverB,string DeliverC,string DeliverD);      //Prints all restaurant info on the status bar at certain timestep

	/// ==>
	// added functions
  Region* getRegions();
   int getAutoS();
   void AddtoOrdersList(Order* po);   //adds an order to the suitable queue of orders
   void AutoPromote();                  //automatically promotes normal orders 
   void UpdateDrawingList();              //Updates drawing list every timestep
   void incrementWaitTime();               //Increments wait time for active orders every time step
   void incrementRestTime();               //Increments rest time for available motorcycles every time step
   void incrementRepairTime();             //Increments repair time for damaged motorcycles every time step
   void Deliver(string& DeliverA,string& DeliverB,string& DeliverC,string& DeliverD);   //this function is responsible for assigning motorcycles in phase 2 
   bool AllDelivered();                    //this function returns true if there is no more active orders in all lists
   bool AllFinished();                     //this function returns true if there is no more in service orders
   void BackIdle();                       //returns the motorcycle back to available list at return timestep
   void RepairMotorcycles();                //returns the motorcycle back to available list after being repaired (repair time passes)
   void Complain(int ID);                  //recieves a complain for a finished VIP order and deallocates it and remove from finished orders
   void returnOrder(string& DeliverA,string& DeliverB,string& DeliverC,string& DeliverD);   //returns a complain order to restaurant
   bool AllReturned();                     //this function returns true if there is no more complaint orders
};

#endif